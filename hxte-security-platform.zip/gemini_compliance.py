"""
HXTE Gemini Compliance Engine - Google Gemini Integration
Advanced AI-powered compliance assessment using Google Gemini API
"""

import requests
import json
import time
import os
from typing import Dict, List, Any
from hxte_config import GOOGLE_API_KEY

class HXTEGeminiCompliance:
    def __init__(self):
        self.api_key = GOOGLE_API_KEY
        self.base_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent"
        
        # Framework definitions for Gemini
        self.frameworks = {
            'SOC2': {
                'description': 'SOC 2 Type II compliance for service organizations',
                'requirements': ['Security', 'Availability', 'Processing Integrity', 'Confidentiality', 'Privacy'],
                'industry_focus': ['Technology', 'SaaS', 'Cloud Services']
            },
            'PCI-DSS': {
                'description': 'Payment Card Industry Data Security Standard',
                'requirements': ['Network Security', 'Data Protection', 'Access Control', 'Network Monitoring', 'Security Testing'],
                'industry_focus': ['Finance', 'E-commerce', 'Retail']
            },
            'ISO27001': {
                'description': 'Information Security Management System standard',
                'requirements': ['Information Security Policy', 'Organization of Information Security', 'Human Resource Security', 'Asset Management', 'Access Control'],
                'industry_focus': ['All Industries']
            },
            'HIPAA': {
                'description': 'Health Insurance Portability and Accountability Act',
                'requirements': ['Administrative Safeguards', 'Physical Safeguards', 'Technical Safeguards', 'Organizational Requirements'],
                'industry_focus': ['Healthcare', 'Medical', 'Health Services']
            },
            'GDPR': {
                'description': 'General Data Protection Regulation',
                'requirements': ['Data Protection by Design', 'Data Subject Rights', 'Consent Management', 'Data Breach Notification', 'Privacy Impact Assessment'],
                'industry_focus': ['All Industries', 'EU Operations']
            }
        }
    
    def analyze_compliance_with_gemini(self, company_name: str, industry: str, company_size: str, frameworks: List[str]) -> Dict[str, Any]:
        """
        Use Google Gemini to analyze company compliance
        """
        print(f"🤖 Gemini analyzing {company_name} for {frameworks} compliance...")
        
        try:
            # Prepare Gemini prompt
            prompt = self._create_compliance_prompt(company_name, industry, company_size, frameworks)
            
            # Call Gemini API
            response = self._call_gemini_api(prompt)
            
            # Parse Gemini response
            analysis = self._parse_gemini_response(response, company_name, industry, company_size, frameworks)
            
            return analysis
            
        except Exception as e:
            print(f"❌ Gemini Error: {str(e)}")
            raise Exception(f"Google Gemini API failed: {str(e)}")
    
    def _create_compliance_prompt(self, company_name: str, industry: str, company_size: str, frameworks: List[str]) -> str:
        """
        Create comprehensive prompt for Gemini
        """
        framework_descriptions = []
        for framework in frameworks:
            if framework in self.frameworks:
                framework_descriptions.append(f"- {framework}: {self.frameworks[framework]['description']}")
        
        prompt = f"""
You are HXTE AI, an advanced cybersecurity compliance assessment AI powered by Google Gemini. Analyze the following company for compliance assessment:

COMPANY PROFILE:
- Name: {company_name}
- Industry: {industry}
- Company Size: {company_size}
- Compliance Frameworks: {', '.join(frameworks)}

FRAMEWORK REQUIREMENTS:
{chr(10).join(framework_descriptions)}

SCORING METHODOLOGY:
- Overall Score: Weighted average of framework scores (0-100)
- Framework Score: Based on requirements compliance (0-100)
- Company Size Impact: Large companies typically score 10-20 points higher
- Industry Impact: Technology companies typically score 5-15 points higher
- Security Maturity: Based on company profile and industry standards
- Risk Level: Based on security maturity and compliance gaps

Please provide a comprehensive compliance analysis in the following JSON format:

{{
    "company_analysis": {{
        "company_name": "{company_name}",
        "industry": "{industry}",
        "company_size": "{company_size}",
        "security_maturity": 0.0-1.0,
        "data_sensitivity": 0.0-1.0,
        "compliance_complexity": 0.0-1.0,
        "risk_level": "Low/Medium/High",
        "ai_confidence": 0.0-1.0,
        "findings": [
            {{
                "type": "Security Control Type",
                "severity": "Low/Medium/High",
                "description": "Detailed description",
                "impact": "Business impact"
            }}
        ]
    }},
    "framework_results": {{
        "FRAMEWORK_NAME": {{
            "framework": "FRAMEWORK_NAME",
            "overall_score": 0-100,
            "compliance_level": "Critical/Poor/Fair/Good/Excellent",
            "requirements": {{
                "REQUIREMENT_NAME": {{
                    "score": 0-100,
                    "status": "Non-Compliant/Partially Compliant/Compliant",
                    "evidence": ["Evidence 1", "Evidence 2"],
                    "recommendations": ["Recommendation 1", "Recommendation 2"]
                }}
            }},
            "ai_analysis": "Detailed AI analysis of this framework"
        }}
    }},
    "ai_insights": [
        "AI insight 1",
        "AI insight 2",
        "AI insight 3"
    ],
    "overall_score": 0-100,
    "recommendations": [
        {{
            "priority": "High/Medium/Low",
            "category": "Category",
            "title": "Recommendation Title",
            "description": "Detailed description",
            "timeline": "Timeline",
            "ai_confidence": 0.0-1.0
        }}
    ]
}}

IMPORTANT: 
- Base your analysis on realistic industry standards and best practices
- Consider the company size and industry when assessing compliance
- Provide specific, actionable recommendations
- Use realistic scores based on typical compliance maturity for the industry
- Include industry-specific security challenges and requirements
- Make the analysis unique for this specific company profile

Respond ONLY with valid JSON, no additional text.
"""
        return prompt
    
    def _call_gemini_api(self, prompt: str) -> str:
        """
        Call Google Gemini API
        """
        headers = {
            'Content-Type': 'application/json'
        }
        
        data = {
            'contents': [{
                'parts': [{
                    'text': prompt
                }]
            }],
            'generationConfig': {
                'temperature': 0.7,
                'maxOutputTokens': 4000
            }
        }
        
        url = f"{self.base_url}?key={self.api_key}"
        
        try:
            print(f"🔄 Calling Gemini API...")
            response = requests.post(url, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            print("✅ Gemini API call successful!")
            return result['candidates'][0]['content']['parts'][0]['text']
            
        except requests.exceptions.RequestException as e:
            print(f"❌ Gemini API Error: {str(e)}")
            raise Exception(f"Gemini API call failed: {str(e)}")
    
    def _parse_gemini_response(self, response: str, company_name: str, industry: str, company_size: str, frameworks: List[str]) -> Dict[str, Any]:
        """
        Parse Gemini response and validate JSON
        """
        try:
            # Clean response (remove any non-JSON text)
            if '```json' in response:
                response = response.split('```json')[1].split('```')[0]
            elif '```' in response:
                response = response.split('```')[1].split('```')[0]
            
            # Parse JSON
            analysis = json.loads(response.strip())
            
            # Validate and enhance the response
            analysis = self._validate_and_enhance_response(analysis, company_name, industry, company_size, frameworks)
            
            return analysis
            
        except json.JSONDecodeError as e:
            print(f"❌ JSON Parse Error: {str(e)}")
            print(f"Response: {response[:500]}...")
            raise Exception(f"Failed to parse Gemini response: {str(e)}")
    
    def _validate_and_enhance_response(self, analysis: Dict, company_name: str, industry: str, company_size: str, frameworks: List[str]) -> Dict:
        """
        Validate and enhance Gemini response
        """
        # Ensure required fields exist
        if 'company_analysis' not in analysis:
            analysis['company_analysis'] = {}
        
        if 'framework_results' not in analysis:
            analysis['framework_results'] = {}
        
        if 'ai_insights' not in analysis:
            analysis['ai_insights'] = []
        
        if 'recommendations' not in analysis:
            analysis['recommendations'] = []
        
        # Enhance company analysis
        analysis['company_analysis'].update({
            'company_name': company_name,
            'industry': industry,
            'company_size': company_size,
            'timestamp': time.time()
        })
        
        # Ensure framework results exist for all requested frameworks
        for framework in frameworks:
            if framework not in analysis['framework_results']:
                analysis['framework_results'][framework] = {
                    'framework': framework,
                    'overall_score': 50.0,
                    'compliance_level': 'Fair',
                    'requirements': {},
                    'ai_analysis': f'Gemini analysis for {framework} compliance'
                }
        
        # Calculate overall score using advanced risk assessment formula
        if 'overall_score' not in analysis:
            analysis['overall_score'] = self._calculate_advanced_risk_score(analysis)
        
        return analysis
    
    def _calculate_advanced_risk_score(self, analysis: Dict) -> float:
        """
        Calculate advanced risk score based on multiple factors
        Formula: Risk Score = Base Score - (Critical Issues * 15) - (High Issues * 10) - (Medium Issues * 5) - (Low Issues * 2) + (Compliance Bonus * 5)
        """
        base_score = 100.0
        
        # Count security findings by severity
        critical_issues = 0
        high_issues = 0
        medium_issues = 0
        low_issues = 0
        
        if 'company_analysis' in analysis and 'findings' in analysis['company_analysis']:
            for finding in analysis['company_analysis']['findings']:
                severity = finding.get('severity', 'Low').lower()
                if severity == 'critical':
                    critical_issues += 1
                elif severity == 'high':
                    high_issues += 1
                elif severity == 'medium':
                    medium_issues += 1
                else:
                    low_issues += 1
        
        # Count framework compliance issues
        framework_issues = 0
        if 'framework_results' in analysis:
            for framework_name, framework_data in analysis['framework_results'].items():
                if 'requirements' in framework_data:
                    for req_name, req_data in framework_data['requirements'].items():
                        status = req_data.get('status', 'Compliant').lower()
                        if 'non-compliant' in status:
                            framework_issues += 1
                        elif 'partially' in status:
                            framework_issues += 0.5
        
        # Calculate compliance bonus
        compliance_bonus = 0
        if 'framework_results' in analysis:
            compliant_frameworks = 0
            total_frameworks = len(analysis['framework_results'])
            for framework_data in analysis['framework_results'].values():
                if framework_data.get('compliance_level', '').lower() in ['good', 'excellent']:
                    compliant_frameworks += 1
            compliance_bonus = (compliant_frameworks / total_frameworks) * 5 if total_frameworks > 0 else 0
        
        # Apply risk formula
        risk_score = base_score
        risk_score -= critical_issues * 15  # Critical issues heavily penalize
        risk_score -= high_issues * 10      # High issues significantly penalize
        risk_score -= medium_issues * 5     # Medium issues moderately penalize
        risk_score -= low_issues * 2        # Low issues slightly penalize
        risk_score -= framework_issues * 3  # Framework issues penalize
        risk_score += compliance_bonus      # Compliance bonus rewards
        
        # Ensure score is within bounds
        risk_score = max(0, min(100, risk_score))
        
        return round(risk_score, 1)
    
    def test_gemini_connection(self) -> bool:
        """
        Test Gemini API connection
        """
        try:
            test_prompt = "Say hello and confirm you are working"
            response = self._call_gemini_api(test_prompt)
            print(f"✅ Gemini Response: {response[:100]}...")
            return "hello" in response.lower() or "working" in response.lower()
        except Exception as e:
            print(f"❌ Gemini Test Failed: {str(e)}")
            return False
    
    def test_gemini_api_key_format(self) -> Dict[str, Any]:
        """
        Test API key format
        """
        api_key = self.api_key
        is_valid_format = isinstance(api_key, str) and len(api_key) > 0
        return {
            "api_key": api_key[:20] + "..." if is_valid_format else "N/A",
            "length": len(api_key) if is_valid_format else 0,
            "valid_format": is_valid_format
        }
