"""
HXTE Configuration - Environment Variables
"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# OpenAI Configuration
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', 'sk-your-openai-api-key-here')

# TODO: Replace with your actual OpenAI API key
# OPENAI_API_KEY = 'sk-your-actual-openai-api-key-here'

# Manual API Key Setup (uncomment and add your key)
# OPENAI_API_KEY = 'sk-your-actual-openai-api-key-here'
# 
# API Key'inizi buraya yazın:
# Yeni API key'inizi buraya yazın:
OPENAI_API_KEY = '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'

# Flask Configuration
SECRET_KEY = os.environ.get('SECRET_KEY', 'hxte-secret-key-2025')
DATABASE_URL = os.environ.get('DATABASE_URL', 'sqlite:///hxte_security.db')

# Other API Keys
ANTHROPIC_API_KEY = os.environ.get('ANTHROPIC_API_KEY', '')
GOOGLE_API_KEY = os.environ.get('GOOGLE_API_KEY', 'your-google-api-key-here')

# Gemini API Key Setup
# Google API key'inizi buraya yazın:
GOOGLE_API_KEY = 'AIzaSyDjG3OZGaGQeCOLtE_gUAsmUQI1Mu-Vcrw'

# HXTE Configuration
HXTE_VERSION = "2.0.0"
HXTE_AI_ENGINE = "Google Gemini + HXTE AI"
