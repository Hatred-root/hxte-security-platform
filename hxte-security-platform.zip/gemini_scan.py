"""
HXTE Gemini Security Scanning Module
AI-powered security scanning with Google Gemini
"""

import requests
import json
import time
from typing import Dict, List, Any
from hxte_config import GOOGLE_API_KEY

class HXTEGeminiScan:
    def __init__(self):
        self.api_key = GOOGLE_API_KEY
        self.base_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent"
        
        # Scan categories
        self.scan_categories = {
            'vulnerability': {
                'description': 'Vulnerability scanning',
                'scans': ['CVE Database', 'Configuration Issues', 'Outdated Software', 'Security Misconfigurations']
            },
            'network': {
                'description': 'Network security scanning',
                'scans': ['Port Scanning', 'Service Detection', 'Network Mapping', 'Traffic Analysis']
            },
            'web': {
                'description': 'Web application scanning',
                'scans': ['SQL Injection', 'XSS', 'CSRF', 'Authentication Issues', 'Input Validation']
            },
            'malware': {
                'description': 'Malware detection scanning',
                'scans': ['File Analysis', 'Behavior Analysis', 'Signature Detection', 'Heuristic Analysis']
            }
        }
    
    def analyze_scan_with_gemini(self, target: str, scan_type: str, scan_depth: str) -> Dict[str, Any]:
        """
        Use Google Gemini to analyze security scanning
        """
        print(f"🤖 Gemini analyzing {target} for {scan_type} security scanning...")
        
        try:
            prompt = self._create_scan_prompt(target, scan_type, scan_depth)
            response = self._call_gemini_api(prompt)
            analysis = self._parse_gemini_response(response, target, scan_type, scan_depth)
            return analysis
            
        except Exception as e:
            print(f"❌ Gemini Error: {str(e)}")
            raise Exception(f"Google Gemini API failed: {str(e)}")
    
    def _create_scan_prompt(self, target: str, scan_type: str, scan_depth: str) -> str:
        """
        Create comprehensive prompt for Gemini scan analysis
        """
        category_info = self.scan_categories.get(scan_type, self.scan_categories['vulnerability'])
        
        prompt = f"""
You are HXTE AI, an advanced cybersecurity scanning AI powered by Google Gemini. Analyze the following target for security scanning:

SCAN PROFILE:
- Target: {target}
- Scan Type: {scan_type}
- Scan Depth: {scan_depth}
- Category: {category_info['description']}

AVAILABLE SCANS:
{', '.join(category_info['scans'])}

SCANNING METHODOLOGY:
- Discovery: Identifying targets and services
- Enumeration: Gathering detailed information
- Vulnerability Detection: Finding security weaknesses
- Exploitation: Testing for exploitable vulnerabilities
- Reporting: Documenting findings and recommendations

Please provide a comprehensive security scan analysis in the following JSON format:

{{
    "target_analysis": {{
        "target": "{target}",
        "scan_type": "{scan_type}",
        "scan_depth": "{scan_depth}",
        "scan_status": "Completed/In Progress/Failed",
        "vulnerability_count": 0,
        "risk_level": "Low/Medium/High/Critical",
        "ai_confidence": 0.0-1.0
    }},
    "discovered_services": [
        {{
            "service": "Service Name",
            "port": "Port Number",
            "version": "Service Version",
            "status": "Open/Closed/Filtered",
            "vulnerabilities": ["Vulnerability 1", "Vulnerability 2"]
        }}
    ],
    "vulnerability_findings": [
        {{
            "cve_id": "CVE-XXXX-XXXX",
            "severity": "Critical/High/Medium/Low",
            "description": "Vulnerability description",
            "affected_service": "Affected service",
            "cvss_score": 0.0-10.0,
            "exploitability": "Easy/Medium/Hard",
            "remediation": "How to fix"
        }}
    ],
    "security_issues": [
        {{
            "issue_type": "Issue Type",
            "severity": "High/Medium/Low",
            "description": "Issue description",
            "affected_components": "Components affected",
            "recommendation": "How to resolve"
        }}
    ],
    "scan_recommendations": [
        {{
            "priority": "Critical/High/Medium/Low",
            "category": "Security Control",
            "title": "Recommendation Title",
            "description": "Detailed recommendation",
            "implementation": "How to implement",
            "timeline": "Implementation timeline"
        }}
    ],
    "overall_security_score": 0-100,
    "ai_insights": [
        "AI insight 1 about security posture",
        "AI insight 2 about vulnerabilities",
        "AI insight 3 about recommendations"
    ]
}}

IMPORTANT:
- Base your analysis on realistic security scanning scenarios
- Consider the target type and scan depth when assessing vulnerabilities
- Provide specific, actionable recommendations
- Use realistic security scores based on typical scan results
- Include industry-standard scanning practices
- Make the analysis unique for this specific target

Respond ONLY with valid JSON, no additional text.
"""
        return prompt
    
    def _call_gemini_api(self, prompt: str) -> str:
        """
        Call Google Gemini API
        """
        headers = {
            'Content-Type': 'application/json'
        }
        
        data = {
            'contents': [{
                'parts': [{
                    'text': prompt
                }]
            }],
            'generationConfig': {
                'temperature': 0.7,
                'maxOutputTokens': 4000
            }
        }
        
        try:
            url = f"{self.base_url}?key={self.api_key}"
            response = requests.post(url, headers=headers, json=data, timeout=60)
            response.raise_for_status()
            
            result = response.json()
            return result['candidates'][0]['content']['parts'][0]['text']
            
        except requests.exceptions.RequestException as e:
            print(f"❌ Gemini API Error: {str(e)}")
            raise Exception(f"Gemini API call failed: {str(e)}")
    
    def _parse_gemini_response(self, response: str, target: str, scan_type: str, scan_depth: str) -> Dict[str, Any]:
        """
        Parse Gemini response and validate
        """
        try:
            # Clean response
            if '```json' in response:
                response = response.split('```json')[1].split('```')[0]
            elif '```' in response:
                response = response.split('```')[1].split('```')[0]
            
            # Parse JSON
            analysis = json.loads(response.strip())
            
            # Validate and enhance the response
            analysis = self._validate_and_enhance_response(analysis, target, scan_type, scan_depth)
            
            return analysis
            
        except json.JSONDecodeError as e:
            print(f"❌ JSON Parse Error: {str(e)}")
            print(f"Response: {response[:500]}...")
            raise Exception(f"Failed to parse Gemini response: {str(e)}")
    
    def _validate_and_enhance_response(self, analysis: Dict, target: str, scan_type: str, scan_depth: str) -> Dict:
        """
        Validate and enhance Gemini response
        """
        # Ensure required fields exist
        if 'target_analysis' not in analysis:
            analysis['target_analysis'] = {}
        
        if 'discovered_services' not in analysis:
            analysis['discovered_services'] = []
        
        if 'vulnerability_findings' not in analysis:
            analysis['vulnerability_findings'] = []
        
        if 'security_issues' not in analysis:
            analysis['security_issues'] = []
        
        if 'scan_recommendations' not in analysis:
            analysis['scan_recommendations'] = []
        
        if 'ai_insights' not in analysis:
            analysis['ai_insights'] = []
        
        # Enhance target analysis
        analysis['target_analysis'].update({
            'target': target,
            'scan_type': scan_type,
            'scan_depth': scan_depth,
            'timestamp': time.time()
        })
        
        # Calculate overall security score using advanced risk assessment formula
        if 'overall_security_score' not in analysis:
            analysis['overall_security_score'] = self._calculate_advanced_risk_score(analysis)
        
        return analysis
    
    def _calculate_advanced_risk_score(self, analysis: Dict) -> float:
        """
        Calculate advanced risk score for security scanning
        Formula: Risk Score = Base Score - (Critical Vulns * 22) - (High Vulns * 16) - (Medium Vulns * 10) - (Low Vulns * 4) + (Security Controls * 3)
        """
        base_score = 100.0
        
        # Count vulnerabilities by severity
        critical_vulns = 0
        high_vulns = 0
        medium_vulns = 0
        low_vulns = 0
        
        if 'vulnerability_findings' in analysis:
            for vuln in analysis['vulnerability_findings']:
                severity = vuln.get('severity', 'Low').lower()
                if severity == 'critical':
                    critical_vulns += 1
                elif severity == 'high':
                    high_vulns += 1
                elif severity == 'medium':
                    medium_vulns += 1
                else:
                    low_vulns += 1
        
        # Count security issues
        if 'security_issues' in analysis:
            for issue in analysis['security_issues']:
                severity = issue.get('severity', 'Low').lower()
                if severity == 'high':
                    high_vulns += 1
                elif severity == 'medium':
                    medium_vulns += 1
                else:
                    low_vulns += 1
        
        # Count discovered services (positive factor - more services = more attack surface)
        discovered_services = 0
        if 'discovered_services' in analysis:
            discovered_services = len(analysis['discovered_services'])
        
        # Count security controls (positive factor)
        security_controls = 0
        if 'scan_recommendations' in analysis:
            security_controls = len([rec for rec in analysis['scan_recommendations'] if rec.get('priority') == 'High'])
        
        # Apply risk formula
        risk_score = base_score
        risk_score -= critical_vulns * 22    # Critical vulnerabilities heavily penalize
        risk_score -= high_vulns * 16         # High vulnerabilities significantly penalize
        risk_score -= medium_vulns * 10       # Medium vulnerabilities moderately penalize
        risk_score -= low_vulns * 4           # Low vulnerabilities slightly penalize
        risk_score -= discovered_services * 1 # More services = more attack surface
        risk_score += security_controls * 3    # Security controls provide bonus
        
        # Ensure score is within bounds
        risk_score = max(0, min(100, risk_score))
        
        return round(risk_score, 1)
    
    def test_gemini_connection(self) -> bool:
        """
        Test Gemini API connection
        """
        try:
            test_prompt = "Say hello and confirm you are working"
            response = self._call_gemini_api(test_prompt)
            print(f"✅ Gemini Response: {response[:100]}...")
            return "hello" in response.lower() or "working" in response.lower()
        except Exception as e:
            print(f"❌ Gemini Test Failed: {str(e)}")
            return False
