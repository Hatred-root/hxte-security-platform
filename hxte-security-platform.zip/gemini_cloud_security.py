"""
HXTE Gemini Cloud Security Module
AI-powered cloud security assessment with Google Gemini
"""

import requests
import json
import time
from typing import Dict, List, Any
from hxte_config import GOOGLE_API_KEY

class HXTEGeminiCloudSecurity:
    def __init__(self):
        self.api_key = GOOGLE_API_KEY
        self.base_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-002:generateContent"
        
        # Cloud security categories
        self.cloud_categories = {
            'compute': {
                'description': 'Cloud compute security assessment',
                'services': ['EC2', 'Lambda', 'ECS', 'EKS', 'Fargate', 'Auto Scaling']
            },
            'storage': {
                'description': 'Cloud storage security assessment',
                'services': ['S3', 'EBS', 'EFS', 'FSx', 'Backup', 'Glacier']
            },
            'network': {
                'description': 'Cloud network security assessment',
                'services': ['VPC', 'Security Groups', 'NACLs', 'WAF', 'CloudFront', 'Route53']
            },
            'identity': {
                'description': 'Cloud identity and access management',
                'services': ['IAM', 'Cognito', 'SSO', 'Directory Service', 'KMS', 'Secrets Manager']
            },
            'database': {
                'description': 'Cloud database security assessment',
                'services': ['RDS', 'DynamoDB', 'ElastiCache', 'Redshift', 'DocumentDB', 'Neptune']
            },
            'monitoring': {
                'description': 'Cloud monitoring and logging security',
                'services': ['CloudWatch', 'CloudTrail', 'Config', 'GuardDuty', 'Security Hub', 'Inspector']
            }
        }
    
    def analyze_cloud_security_with_gemini(self, cloud_provider: str, service_type: str, security_scope: str) -> Dict[str, Any]:
        """
        Use Google Gemini to analyze cloud security
        """
        print(f"🤖 Gemini analyzing {cloud_provider} for {service_type} cloud security...")
        
        try:
            prompt = self._create_cloud_security_prompt(cloud_provider, service_type, security_scope)
            response = self._call_gemini_api(prompt)
            analysis = self._parse_gemini_response(response, cloud_provider, service_type, security_scope)
            return analysis
            
        except Exception as e:
            print(f"❌ Gemini Error: {str(e)}")
            raise Exception(f"Google Gemini API failed: {str(e)}")
    
    def _create_cloud_security_prompt(self, cloud_provider: str, service_type: str, security_scope: str) -> str:
        """
        Create comprehensive prompt for Gemini cloud security analysis
        """
        category_info = self.cloud_categories.get(service_type, self.cloud_categories['compute'])
        
        prompt = f"""
You are HXTE AI, an advanced cloud security assessment AI powered by Google Gemini. Analyze the following cloud environment for security assessment:

CLOUD PROFILE:
- Cloud Provider: {cloud_provider}
- Service Type: {service_type}
- Security Scope: {security_scope}
- Category: {category_info['description']}

AVAILABLE SERVICES:
{', '.join(category_info['services'])}

IMPORTANT: The Security Scope "{security_scope}" is the PRIMARY focus of this assessment. 
Base your analysis, findings, and recommendations specifically on what the user requested in the security scope.
If the scope mentions specific compliance frameworks, focus on those.
If the scope mentions specific resources, focus on those.
If the scope mentions specific security concerns, prioritize those.

CLOUD SECURITY METHODOLOGY:
- Configuration Review: Analyzing cloud resource configurations
- Access Control Assessment: Evaluating IAM policies and permissions
- Network Security Analysis: Reviewing network configurations and security groups
- Data Protection Assessment: Analyzing data encryption and backup strategies
- Compliance Evaluation: Checking against security frameworks and best practices
- Threat Modeling: Identifying potential security risks and attack vectors

Please provide a comprehensive cloud security analysis in the following JSON format:

{{
    "cloud_analysis": {{
        "cloud_provider": "{cloud_provider}",
        "service_type": "{service_type}",
        "security_scope": "{security_scope}",
        "security_posture": "Poor/Fair/Good/Excellent",
        "risk_level": "Low/Medium/High/Critical",
        "compliance_status": "Non-Compliant/Partially Compliant/Compliant",
        "ai_confidence": 0.0-1.0
    }},
    "configuration_findings": [
        {{
            "service": "Service Name",
            "severity": "Critical/High/Medium/Low",
            "finding": "Security finding description",
            "impact": "Potential business impact",
            "recommendation": "How to fix this issue"
        }}
    ],
    "access_control_assessment": {{
        "iam_policies": [
            {{
                "policy_name": "Policy Name",
                "severity": "High/Medium/Low",
                "issue": "Policy issue description",
                "recommendation": "Policy improvement suggestion"
            }}
        ],
        "permissions_analysis": {{
            "overprivileged_users": ["User 1", "User 2"],
            "unused_permissions": ["Permission 1", "Permission 2"],
            "security_recommendations": ["Recommendation 1", "Recommendation 2"]
        }}
    }},
    "network_security": {{
        "vpc_configuration": {{
            "public_subnets": "Number of public subnets",
            "private_subnets": "Number of private subnets",
            "security_groups": "Security group analysis",
            "recommendations": ["Network recommendation 1", "Network recommendation 2"]
        }},
        "firewall_rules": [
            {{
                "rule_name": "Rule Name",
                "severity": "High/Medium/Low",
                "issue": "Firewall rule issue",
                "recommendation": "How to improve this rule"
            }}
        ]
    }},
    "data_protection": {{
        "encryption_status": {{
            "data_at_rest": "Encrypted/Not Encrypted",
            "data_in_transit": "Encrypted/Not Encrypted",
            "key_management": "Key management analysis"
        }},
        "backup_strategy": {{
            "backup_frequency": "Daily/Weekly/Monthly",
            "retention_policy": "Retention policy analysis",
            "recovery_testing": "Recovery testing status"
        }}
    }},
    "compliance_assessment": {{
        "framework_compliance": {{
            "SOC2": "Compliant/Partially Compliant/Non-Compliant",
            "ISO27001": "Compliant/Partially Compliant/Non-Compliant",
            "PCI-DSS": "Compliant/Partially Compliant/Non-Compliant"
        }},
        "security_controls": [
            {{
                "control_name": "Control Name",
                "status": "Implemented/Partially Implemented/Not Implemented",
                "description": "Control description",
                "recommendation": "Implementation recommendation"
            }}
        ]
    }},
    "threat_analysis": {{
        "identified_threats": [
            {{
                "threat_name": "Threat Name",
                "severity": "Critical/High/Medium/Low",
                "description": "Threat description",
                "mitigation": "How to mitigate this threat"
            }}
        ],
        "attack_vectors": [
            "Potential attack vector 1",
            "Potential attack vector 2"
        ]
    }},
    "recommendations": [
        {{
            "priority": "Critical/High/Medium/Low",
            "category": "Security Category",
            "title": "Recommendation Title",
            "description": "Detailed recommendation",
            "implementation": "How to implement",
            "timeline": "Implementation timeline"
        }}
    ],
    "overall_security_score": 0-100,
    "ai_insights": [
        "AI insight 1 about cloud security posture",
        "AI insight 2 about security improvements",
        "AI insight 3 about compliance recommendations"
    ]
}}

IMPORTANT:
- Base your analysis on realistic cloud security scenarios
- Consider the cloud provider and service type when assessing security
- Provide specific, actionable recommendations
- Use realistic security scores based on typical cloud environments
- Include industry-standard cloud security practices
- Make the analysis unique for this specific cloud configuration

Respond ONLY with valid JSON, no additional text.
"""
        return prompt
    
    def _call_gemini_api(self, prompt: str) -> str:
        """
        Call Google Gemini API with retry logic and fallback
        """
        headers = {
            'Content-Type': 'application/json'
        }
        
        data = {
            'contents': [{
                'parts': [{
                    'text': prompt
                }]
            }],
            'generationConfig': {
                'temperature': 0.7,
                'maxOutputTokens': 4000
            }
        }
        
        # Retry logic for rate limiting
        max_retries = 2  # Reduced retries
        retry_delay = 10  # Reduced delay
        
        for attempt in range(max_retries):
            try:
                print(f"🔄 Gemini API attempt {attempt + 1}/{max_retries}")
                url = f"{self.base_url}?key={self.api_key}"
                response = requests.post(url, headers=headers, json=data, timeout=30)  # Reduced timeout
                
                if response.status_code == 429:
                    print(f"⏳ Rate limit hit, waiting {retry_delay} seconds...")
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                    continue
                
                response.raise_for_status()
                
                result = response.json()
                print("✅ Gemini API call successful!")
                
                # Check if response has content
                if 'candidates' in result and len(result['candidates']) > 0:
                    if 'content' in result['candidates'][0] and 'parts' in result['candidates'][0]['content']:
                        if len(result['candidates'][0]['content']['parts']) > 0:
                            return result['candidates'][0]['content']['parts'][0]['text']
                
                print("⚠️ Empty response from Gemini API")
                raise Exception("Empty response from Gemini API")
                
            except requests.exceptions.RequestException as e:
                if attempt == max_retries - 1:  # Last attempt
                    print(f"❌ Gemini API Error: {str(e)}")
                    raise Exception(f"Gemini API call failed: {str(e)}")
                else:
                    print(f"⚠️ Attempt {attempt + 1} failed: {str(e)}, retrying...")
                    time.sleep(5)
        
        # If all retries failed, raise exception
        raise Exception("All Gemini API attempts failed")
    
    def _parse_gemini_response(self, response: str, cloud_provider: str, service_type: str, security_scope: str) -> Dict[str, Any]:
        """
        Parse Gemini response and validate
        """
        try:
            # Clean response with null check
            if response is None:
                raise Exception("Empty response from Gemini API")
                
            if '```json' in response:
                response = response.split('```json')[1].split('```')[0]
            elif '```' in response:
                response = response.split('```')[1].split('```')[0]
            
            # Parse JSON
            analysis = json.loads(response.strip())
            
            # Validate and enhance the response
            analysis = self._validate_and_enhance_response(analysis, cloud_provider, service_type, security_scope)
            
            return analysis
            
        except json.JSONDecodeError as e:
            print(f"❌ JSON Parse Error: {str(e)}")
            print(f"Response: {response[:500]}...")
            raise Exception(f"Failed to parse Gemini response: {str(e)}")
    
    def _validate_and_enhance_response(self, analysis: Dict, cloud_provider: str, service_type: str, security_scope: str) -> Dict:
        """
        Validate and enhance Gemini response with security scope focus
        """
        # Add security scope emphasis to analysis
        analysis['security_scope_focus'] = f"Assessment specifically focused on: {security_scope}"
        
        # Ensure required fields exist
        if 'cloud_analysis' not in analysis:
            analysis['cloud_analysis'] = {}
        
        if 'configuration_findings' not in analysis:
            analysis['configuration_findings'] = []
        
        if 'access_control_assessment' not in analysis:
            analysis['access_control_assessment'] = {}
        
        if 'network_security' not in analysis:
            analysis['network_security'] = {}
        
        if 'data_protection' not in analysis:
            analysis['data_protection'] = {}
        
        if 'compliance_assessment' not in analysis:
            analysis['compliance_assessment'] = {}
        
        if 'threat_analysis' not in analysis:
            analysis['threat_analysis'] = {}
        
        if 'recommendations' not in analysis:
            analysis['recommendations'] = []
        
        if 'ai_insights' not in analysis:
            analysis['ai_insights'] = []
        
        # Enhance cloud analysis
        analysis['cloud_analysis'].update({
            'cloud_provider': cloud_provider,
            'service_type': service_type,
            'security_scope': security_scope,
            'timestamp': time.time()
        })
        
        # Calculate overall security score using advanced risk assessment formula
        if 'overall_security_score' not in analysis:
            analysis['overall_security_score'] = self._calculate_advanced_risk_score(analysis)
        
        return analysis
    
    def _calculate_advanced_risk_score(self, analysis: Dict) -> float:
        """
        Calculate advanced risk score for cloud security
        Formula: Risk Score = Base Score - (Critical Issues * 18) - (High Issues * 12) - (Medium Issues * 6) - (Low Issues * 2) + (Compliance Bonus * 3)
        """
        base_score = 100.0
        
        # Count configuration findings by severity
        critical_issues = 0
        high_issues = 0
        medium_issues = 0
        low_issues = 0
        
        if 'configuration_findings' in analysis:
            for finding in analysis['configuration_findings']:
                severity = finding.get('severity', 'Low').lower()
                if severity == 'critical':
                    critical_issues += 1
                elif severity == 'high':
                    high_issues += 1
                elif severity == 'medium':
                    medium_issues += 1
                else:
                    low_issues += 1
        
        # Count access control issues
        if 'access_control_assessment' in analysis:
            if 'iam_policies' in analysis['access_control_assessment']:
                for policy in analysis['access_control_assessment']['iam_policies']:
                    severity = policy.get('severity', 'Low').lower()
                    if severity == 'high':
                        high_issues += 1
                    elif severity == 'medium':
                        medium_issues += 1
                    else:
                        low_issues += 1
        
        # Count network security issues
        if 'network_security' in analysis and 'firewall_rules' in analysis['network_security']:
            for rule in analysis['network_security']['firewall_rules']:
                severity = rule.get('severity', 'Low').lower()
                if severity == 'high':
                    high_issues += 1
                elif severity == 'medium':
                    medium_issues += 1
                else:
                    low_issues += 1
        
        # Count threat analysis issues
        if 'threat_analysis' in analysis and 'identified_threats' in analysis['threat_analysis']:
            for threat in analysis['threat_analysis']['identified_threats']:
                severity = threat.get('severity', 'Low').lower()
                if severity == 'critical':
                    critical_issues += 1
                elif severity == 'high':
                    high_issues += 1
                elif severity == 'medium':
                    medium_issues += 1
                else:
                    low_issues += 1
        
        # Calculate compliance bonus
        compliance_bonus = 0
        if 'compliance_assessment' in analysis and 'framework_compliance' in analysis['compliance_assessment']:
            compliant_frameworks = 0
            total_frameworks = len(analysis['compliance_assessment']['framework_compliance'])
            for framework, status in analysis['compliance_assessment']['framework_compliance'].items():
                if status.lower() == 'compliant':
                    compliant_frameworks += 1
            compliance_bonus = (compliant_frameworks / total_frameworks) * 3 if total_frameworks > 0 else 0
        
        # Apply risk formula
        risk_score = base_score
        risk_score -= critical_issues * 18    # Critical issues heavily penalize
        risk_score -= high_issues * 12        # High issues significantly penalize
        risk_score -= medium_issues * 6       # Medium issues moderately penalize
        risk_score -= low_issues * 2          # Low issues slightly penalize
        risk_score += compliance_bonus         # Compliance bonus rewards
        
        # Ensure score is within bounds
        risk_score = max(0, min(100, risk_score))
        
        return round(risk_score, 1)
    
    def test_gemini_connection(self) -> bool:
        """
        Test Gemini API connection
        """
        try:
            test_prompt = "Say hello and confirm you are working"
            response = self._call_gemini_api(test_prompt)
            print(f"✅ Gemini Response: {response[:100]}...")
            return "hello" in response.lower() or "working" in response.lower()
        except Exception as e:
            print(f"❌ Gemini Test Failed: {str(e)}")
            return False
