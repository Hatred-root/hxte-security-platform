"""
HXTE - Complete Security Platform with Gemini AI
Full-featured HXTE application with all original features
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
from datetime import datetime
import json
import os

# Import Gemini modules
from gemini_compliance import HXTEGeminiCompliance
from gemini_pentest import HXTEGeminiPentest
from gemini_cloud_security import HXTEGeminiCloudSecurity
from gemini_scan import HXTEGeminiScan

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hxte-secret-key-2025'
CORS(app)

# Initialize Gemini AI engines
gemini_compliance = HXTEGeminiCompliance()
gemini_pentest = HXTEGeminiPentest()
gemini_cloud_security = HXTEGeminiCloudSecurity()
gemini_scan = HXTEGeminiScan()

# Global sessions
sessions = {}

@app.route('/')
def index():
    """HXTE Dashboard - Main page"""
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    """HXTE Dashboard"""
    return render_template('dashboard.html')

@app.route('/compliance')
def compliance():
    """Compliance assessment page"""
    frameworks = ['SOC2', 'PCI-DSS', 'ISO27001', 'HIPAA', 'GDPR', 'NIST']
    return render_template('compliance.html', frameworks=frameworks)

@app.route('/pentest')
def pentest():
    """Penetration testing page"""
    return render_template('pentest.html')

@app.route('/cloud-security')
def cloud_security():
    """Cloud security assessment page"""
    return render_template('cloud_security.html')

@app.route('/scan')
def scan():
    """Security scanning page"""
    return render_template('scan.html')

@app.route('/login')
def login():
    """Login page"""
    return render_template('login.html')

@app.route('/register')
def register():
    """Register page"""
    return render_template('register.html')

# API Endpoints

@app.route('/api/compliance', methods=['POST'])
def assess_compliance():
    """HXTE AI-powered compliance assessment with Google Gemini"""
    try:
        data = request.get_json()
        company_name = data.get('organization', data.get('company_name', 'Unknown Company'))
        industry = data.get('industry', 'Technology')
        company_size = data.get('company_size', 'Medium')
        frameworks = data.get('frameworks', ['SOC2'])
        
        print(f"🤖 Gemini analyzing {company_name} for {frameworks} compliance...")
        
        # Use ONLY Gemini for compliance analysis
        ai_assessment = gemini_compliance.analyze_compliance_with_gemini(
            company_name, industry, company_size, frameworks
        )
        ai_engine = "Google Gemini (AI)"
        
        return jsonify({
            'success': True,
            'assessment': ai_assessment,
            'ai_engine': ai_engine,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Compliance assessment failed: {str(e)}'
        })

@app.route('/api/pentest', methods=['POST'])
def assess_pentest():
    """HXTE AI-powered penetration testing with Google Gemini"""
    try:
        data = request.get_json()
        target = data.get('target', 'Unknown Target')
        test_type = data.get('test_type', 'web_application')
        scope = data.get('scope', 'Full Scope')
        
        print(f"🤖 Gemini analyzing {target} for {test_type} penetration testing...")
        
        # Use ONLY Gemini for pentest analysis
        ai_assessment = gemini_pentest.analyze_pentest_with_gemini(
            target, test_type, scope
        )
        ai_engine = "Google Gemini (AI)"
        
        return jsonify({
            'success': True,
            'assessment': ai_assessment,
            'ai_engine': ai_engine,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Penetration testing failed: {str(e)}'
        }), 500

@app.route('/api/cloud-security', methods=['POST'])
def assess_cloud_security():
    """HXTE AI-powered cloud security assessment with Google Gemini"""
    try:
        data = request.get_json()
        cloud_provider = data.get('cloud_provider', 'AWS')
        service_type = data.get('service_type', 'compute')
        security_scope = data.get('security_scope', 'Full Assessment')
        
        print(f"🤖 Gemini analyzing {cloud_provider} for {service_type} cloud security...")
        
        # Use ONLY Gemini for cloud security analysis
        ai_assessment = gemini_cloud_security.analyze_cloud_security_with_gemini(
            cloud_provider, service_type, security_scope
        )
        ai_engine = "Google Gemini (AI)"
        
        return jsonify({
            'success': True,
            'assessment': ai_assessment,
            'ai_engine': ai_engine,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Cloud security assessment failed: {str(e)}'
        }), 500

@app.route('/api/scan', methods=['POST'])
def start_scan():
    """HXTE AI-powered security scanning with Google Gemini"""
    try:
        data = request.get_json()
        target = data.get('target', 'Unknown Target')
        scan_type = data.get('scan_type', 'vulnerability')
        scan_depth = data.get('scan_depth', 'Standard')
        
        print(f"🤖 Gemini analyzing {target} for {scan_type} security scanning...")
        
        # Use ONLY Gemini for scan analysis
        ai_assessment = gemini_scan.analyze_scan_with_gemini(
            target, scan_type, scan_depth
        )
        ai_engine = "Google Gemini (AI)"
        
        return jsonify({
            'success': True,
            'assessment': ai_assessment,
            'ai_engine': ai_engine,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Security scanning failed: {str(e)}'
        }), 500

@app.route('/api/monitoring', methods=['GET'])
def get_monitoring_data():
    """Get real-time monitoring data"""
    try:
        # Simulate monitoring data
        monitoring_data = {
            'cpu_usage': 45.2,
            'memory_usage': 67.8,
            'network_traffic': 1234.5,
            'active_connections': 156,
            'security_events': 23,
            'alerts': [
                {'type': 'High CPU Usage', 'severity': 'Medium', 'time': datetime.now().isoformat()},
                {'type': 'Suspicious Activity', 'severity': 'High', 'time': datetime.now().isoformat()}
            ]
        }
        
        return jsonify({
            'success': True,
            'data': monitoring_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Monitoring data failed: {str(e)}'
        })

@app.route('/api/pentest', methods=['POST'])
def start_pentest():
    """Start penetration test"""
    try:
        data = request.get_json()
        target = data.get('target', '')
        test_type = data.get('test_type', 'web')
        
        # Generate pentest session
        session_id = f"pentest_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        sessions[session_id] = {
            'target': target,
            'test_type': test_type,
            'status': 'running',
            'start_time': datetime.now().isoformat(),
            'results': []
        }
        
        # Simulate pentest results
        pentest_results = {
            'vulnerabilities': [
                {'type': 'Authentication Bypass', 'severity': 'Critical', 'description': 'Authentication can be bypassed'},
                {'type': 'Privilege Escalation', 'severity': 'High', 'description': 'Privilege escalation possible'},
                {'type': 'Data Exposure', 'severity': 'Medium', 'description': 'Sensitive data exposed'}
            ],
            'recommendations': [
                'Implement strong authentication',
                'Fix privilege escalation vulnerabilities',
                'Encrypt sensitive data'
            ]
        }
        
        sessions[session_id]['results'] = pentest_results
        sessions[session_id]['status'] = 'completed'
        
        return jsonify({
            'success': True,
            'session_id': session_id,
            'results': pentest_results
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Pentest failed: {str(e)}'
        })

if __name__ == '__main__':
    print("🚀 Starting HXTE Complete Security Platform...")
    print("📊 AI Engine: Google Gemini + HXTE AI")
    print("🔒 Security Features: ACTIVE")
    print("⚡ Compliance Analysis: ACTIVE")
    print("🛡️ Penetration Testing: ACTIVE")
    print("📈 Real-time Monitoring: ACTIVE")
    print("🌐 Web Interface: http://localhost:5001")
    
    app.run(debug=True, host='0.0.0.0', port=5001)
